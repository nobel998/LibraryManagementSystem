package interfaces;

public interface Returnable {
    String returnBook();
}
