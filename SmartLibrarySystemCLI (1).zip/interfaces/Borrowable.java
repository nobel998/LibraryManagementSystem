package interfaces;

public interface Borrowable {
    void borrowBook();
}
