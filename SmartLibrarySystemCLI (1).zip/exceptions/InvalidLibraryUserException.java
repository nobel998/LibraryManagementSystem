package exceptions;

public class InvalidLibraryUserException extends Exception {
    public InvalidLibraryUserException(String message) {
        super(message);
    }
}
